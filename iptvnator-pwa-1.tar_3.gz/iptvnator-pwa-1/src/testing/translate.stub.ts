/** Translate Service Stub */
export class TranslateServiceStub {
    instant(): void {}
}
