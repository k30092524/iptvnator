export interface EpgChannel {
    id: string;
    name: { lang: string; value: string }[];
    icon: string[];
    url: string[];
}
