/**
 * Id of the channel with favorite channels aggregated from all added playlists
 */
export const GLOBAL_FAVORITES_PLAYLIST_ID = 'GLOBAL_FAVORITES';
