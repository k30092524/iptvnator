export const AppConfig = {
    production: false,
    environment: 'LOCAL',
    version: require('../../package.json').version,
};
