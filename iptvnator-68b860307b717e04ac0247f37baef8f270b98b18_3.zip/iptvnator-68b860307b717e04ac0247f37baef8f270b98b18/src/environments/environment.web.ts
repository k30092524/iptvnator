export const AppConfig = {
    production: false,
    environment: 'WEB',
    version: require('../../package.json').version,
};
