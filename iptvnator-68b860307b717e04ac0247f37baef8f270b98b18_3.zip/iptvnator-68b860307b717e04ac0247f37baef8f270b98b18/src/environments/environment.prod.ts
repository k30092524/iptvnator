export const AppConfig = {
    production: true,
    environment: 'PROD',
    version: require('../../package.json').version,
};
