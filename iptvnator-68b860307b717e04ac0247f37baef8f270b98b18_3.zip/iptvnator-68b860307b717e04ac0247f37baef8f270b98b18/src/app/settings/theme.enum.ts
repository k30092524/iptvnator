export enum Theme {
    DarkTheme = 'DARK_THEME',
    LightTheme = 'LIGHT_THEME',
}
