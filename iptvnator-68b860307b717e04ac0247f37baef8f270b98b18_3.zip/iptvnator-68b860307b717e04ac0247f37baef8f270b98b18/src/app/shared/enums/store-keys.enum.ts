/** Labels of properties in local storage */
export enum STORE_KEY {
    Settings = 'settings',
    Version = 'version'
}